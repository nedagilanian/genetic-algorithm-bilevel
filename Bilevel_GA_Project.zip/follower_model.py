def solve_follower(a_v, demand):
    total = sum(demand.values())
    return total * 50, total * 1.2
