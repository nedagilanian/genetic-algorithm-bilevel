def repair_individual(ind, max_area):
    ind = [max(0,x) for x in ind]
    s = sum(ind)
    return [x*max_area/s if s>max_area else x for x in ind]
