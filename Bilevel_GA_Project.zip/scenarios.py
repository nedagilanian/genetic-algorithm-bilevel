import numpy as np

def generate_scenarios(level="medium"):
    sigma = {"low":5, "medium":10, "high":20}[level]
    base = {"p1":30, "p2":25}
    return {i:{k:max(0,v+np.random.normal(0,sigma)) for k,v in base.items()} for i in range(5)}
