import random
import numpy as np
from deap import base, creator, tools
from follower_model import solve_follower
from utils import repair_individual
from config import *

creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
creator.create("Individual", list, fitness=creator.FitnessMin)

def run_ga(capacity_current, scenarios):
    toolbox = base.Toolbox()
    toolbox.register("attr_float", random.uniform, 0, WAREHOUSE_AREA)
    toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attr_float, n=len(TECH_NAMES))
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)

    def fitness(ind):
        ind[:] = repair_individual(ind, WAREHOUSE_AREA)
        total_cost = 0
        caps = []
        for s in scenarios.values():
            op, cap = solve_follower(ind, s)
            total_cost += op
            caps.append(cap)
        ind.capacity = np.mean(caps)
        construction = sum(C_v[i]*ind[i] for i in range(len(ind)))
        return (total_cost + construction,)

    toolbox.register("evaluate", fitness)
    toolbox.register("mate", tools.cxBlend, alpha=0.5)
    toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=10, indpb=0.2)
    toolbox.register("select", tools.selTournament, tournsize=3)

    pop = toolbox.population(n=POP_SIZE)
    for _ in range(N_GEN):
        offspring = tools.varAnd(pop, toolbox, CXPB, MUTPB)
        for ind in offspring:
            ind.fitness.values = toolbox.evaluate(ind)
        pop = toolbox.select(offspring, len(pop))

    best = tools.selBest(pop, 1)[0]
    toolbox.evaluate(best)
    return best, best.capacity
