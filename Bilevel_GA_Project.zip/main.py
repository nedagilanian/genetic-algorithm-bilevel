from ga_leader import run_ga
from scenarios import generate_scenarios
from config import *

capacity = INITIAL_CAPACITY

for it in range(MAX_OUTER_ITER):
    print(f"\n--- Outer Iteration {it} ---")
    scenarios = generate_scenarios("medium")
    best_solution, new_capacity = run_ga(capacity, scenarios)

    print("Best a_v:", best_solution)
    print("Capacity:", new_capacity)

    if abs(new_capacity - capacity) <= EPSILON:
        print("✅ Capacity converged")
        break

    capacity = new_capacity
